from menu import show_menu

def main():
    print(" Bienvenido al Sistema de Gestión de Notas ")
    student_list = []
    show_menu(student_list)

if __name__ == "__main__":
    main()
